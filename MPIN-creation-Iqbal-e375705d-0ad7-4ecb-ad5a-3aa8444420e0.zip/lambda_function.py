import boto3
 
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('accountDetails-Iqbal')

def lambda_handler(event, context):
 
    attrs = event["Details"]["ContactData"].get("Attributes", {})
 
    # Auto generated input from Store Customer Input
    MPIN = list(attrs.values())[0] if attrs else None
 
 
    if not account:
        return {"message": "No account received"}

    table.put_item(
        Item={ "MPIN" : MPIN}
    )
